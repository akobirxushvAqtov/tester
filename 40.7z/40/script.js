// let arr = [
//     'Karimov',
//     'Islom',
//     23,
//     'Developer'
// ]
// console.log('Person Name: ' + arr[0])

// let obj = {
//     surName: 'Karimov',
//     name: 'Islom',
//     age: 23,
//     job: 'Developer'
// }
// console.log(obj)
// console.log(obj.name)

/*
let books = [
    {
        title: 'JS Asoslari',
        author: 'Islom',
        pages: 203,
    },
    {
        title: 'Css Asoslari',
        author: 'Islom',
        pages: 250,
    }
]
*/

// let obj = {
//     surName: 'Karimov',
//     name: 'Islom',
//     age: 23,
//     job: 'Developer',
//     fullname: () => {
//         return (obj.surName + ' ' + obj.name)
//     }
// }
// let fullname = obj.fullname()
// console.log(obj)
// console.log(fullname)

/*
let user = {
    surName: 'Karimov',
    name: 'Islom',
    age: 23,
    job: 'Developer',
    posts: [
        {
            title: 'sdasjhsbghsg sdfe',
            body: 'sdfdsfSDffsdfsdfsdsdadg sdfgagawefaewf ',
            date: '2022-06-13'
        },
        {
            title: 'sdasjhsbghsg sdfe',
            body: 'sdfdsfSDffsdfsdfsdsdadg sdfgagawefaewf ',
            date: '2022-06-12'
        }
    ]
}
let str = 'name'
console.log(user.surName)
console.log(user['surName'])
console.log(user[str])
*/ 

/*
let obj = {
    surName: 'Karimov',
    name: 'Islom',
    age: 23,
    job: 'Developer',
    fullname: function(){
        return (this.surName + ' ' + this.name)
    }
}
console.log(obj.fullname())
*/  

// let obj = {
//     surName: 'Karimov',
//     name: 'Islom', 
// }
// let obj2 = {
//     age: 23,
//     job: 'Developer',
//     fullname: function(){
//         return (this.surName + ' ' + this.name)
//     }
// }
// console.log( Object.assign(obj,obj2) ) 

// let a = 5
// let b = a  //5
// a+=5        // 10
// let person1 = {
//     surName: 'Karimov',
//     name: 'Islom',
//     age: 23,
//     job: 'Developer',
//     fullname: function(){
//         return (this.surName + ' ' + this.name)
//     }
// }
// let person2 = person1
// person2.name = 'Asomiddin'
// person2.age = 20
// console.log(person1)
// console.log(person2)


/*
let person1 = {
    surName: 'Karimov',
    name: 'Islom',
    age: 23,
    job: 'Developer',
    fullname: function(){
        return (this.surName + ' ' + this.name)
    }
}
let person2 = Object.assign({}, person1)
person2.name = 'Asomiddin'
person2.age = 20
console.log(person1)
console.log(person2)
*/  

// let person1 = {
//     surName: 'Karimov',
//     name: 'Islom',
//     age: 23,
//     job: 'Developer',
//     fullname: function(){
//         return (this.surName + ' ' + this.name)
//     }
// }
// console.log( Object.keys(person1) )
// console.log( Object.values(person1) )
// console.log( Object.entries(person1) )

