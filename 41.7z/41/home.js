// let books = [
//     {
//         id: 1,
//         name: 'Sariq devni minib',
//         author: 'Xudoyberdi To\'xtaboyev',
//         pages: 356,
//     },
//     {
//         id: 2,
//         name: 'Alximik',
//         author: 'Paolo Koelyo',
//         pages: 153,
//     },
//     {
//         id: 3,
//         name: 'Shaytanat',
//         author: 'Toxir Malik',
//         pages: 864,
//     },
//     {
//         id: 4,
//         name: 'Ufq romani',
//         author: 'Said Ahmad',
//         pages: 482,
//     },
// ]



//     let strBooks = JSON.stringify(books, undefined, 4)
//     // console.log(strBooks)
    
//     localStorage.setItem(books, strBooks)
    
//     let getBooks = localStorage.getItem(books)
//     // console.log(getBooks)
    
//     let objBooks = JSON.parse(getBooks)
//     console.log(objBooks[0])




//     let languages =[
//         'russian',
//         'uzbek',
//         'english',
//         'spain',
//         'japan',
//         'italian',
//         'uzbek',
//         'turk',
//         'azerbaycan',
//         'indonesia',
//         'polski',
//         'Arabic',
//         'turk',
//         'japan',
//         'arabic',
//         'spain'
//  ]


 
// for(elem of languages){
//     if(elem.length == 5){
//         console.log(elem)
//     }
// }




// for(elem of languages){
//     if(elem[0] == 'a'){
//         console.log(elem)
//     }else if(elem[0] == 'A'){
//         console.log(elem)
//     }
// }




// let countriesLanguages = new Map([
//     ['Rossiya', 'russian'],
//     ['Uzbekistan', 'uzbek'],
//     ['USA', 'english'],
//     ['Ispaniya', 'spain']
// ])
// console.log(countriesLanguages)









// let languages = new Set([
//         'russian',
//         'uzbek',
//         'english',
//         'spain',
//         'japan',
//         'italian',
//         'uzbek',
//         'turk',
//         'azerbaycan',
//         'indonesia',
//         'polski',
//         'turk',
//         'japan',
//         'arabic',
//         'spain'
//     ])

//     console.log(languages)
//     console.log(languages.size)