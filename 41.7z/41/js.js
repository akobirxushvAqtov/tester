
// let set = new Set([1,3,6,1,3,6,1])
// console.log(set)


// let set = new Set(['Islom', 'Ozodbek', 'Nurbek','Islom', 'Ozodbek', 'Nurbek'])
// set.add('Akobir')
// set.add('Ozodbek')
// set.delete('Nurbek')
// //set.clear()
// console.log(set)
// console.log(set.size)
// console.log(set.has('Nurbek'))
// console.log(set.has('Ozodbek'))
                                                        
// let set = new Set(['Islom', 'Ozodbek', 'Nurbek','Islom', 'Ozodbek', 'Nurbek'])
// for(item of set){
//     console.log(item)
// }


// let person = [
//     ['name', 'Islom'],
//     ['surName', 'Karimov'],
//     ['age', '23'],
// ]
// let map = new Map(person)
// map.set('gender', 'man')
// console.log(map)
// console.log(map.get('name'))
// console.log(map.has('age'))
// console.log(map.has('pages'))
// for(elem of map){
//     console.log(elem)
// }


// let arr = ['Islom', 'Ozodbek', 'Nurbek']
// let [name1, name2, name3] = arr
// console.log(name1)
// console.log(name2)
// console.log(name3)


/*
let name1 = 'Islom'
let name2 = 'Ozodbek'
let name3 = 'Nurbek'
let arr = [name1, name2, name3]
console.log(arr)
*/ 

// let obj = {
//     name: 'Islom',
//     age: 23,
//     surname: 'Karimov'
// }
// let {name, surname, age} = obj
// console.log(name, age, surname)


// let name = 'Islom'
// let surname = 'Karimov'
// let age = 23
// let obj = {
//     name,
//     lastName: surname,
//     age,
// }
// console.log(obj)

// try{
//     console.log(a)
// } catch(err){
//     console.log(err)
// } finally{
//     console.log('salom')
// }

// console.log(books)

// let str = JSON.stringify(books, undefined, 4)
// console.log(str)
// let obj2 = JSON.parse(str)
// console.log(obj2)

// localStorage.setItem('name', 'Islom')
// let name = localStorage.getItem('name')
// console.log(name)

// let strBooks = JSON.stringify(books, undefined, 4)
// localStorage.setItem('books', strBooks)

// let strBook = localStorage.getItem('books')
// console.log(strBook)
// // let books = JSON.parse(strBook)
// console.log(books[0])

// let books = [
//     {
//         id: 1,
//         name: 'Alximik',
//         author: 'Paolo Koelyo',
//         pages: 153,
//     },
//     {
//         id: 2,
//         name: 'Shaytonat',
//         author: 'Toxir Malik',
//         pages: 864,
//     },
//     {
//         id: 3,
//         name: 'Sariq devni minib',
//         author: 'Xudoyberdi To\'xtaboyev',
//         pages: 356,
//     },
//     {
//         id: 4,
//         name: 'Ufq romani',
//         author: 'O\'tkir Xoshimov',
//         pages: 482,
//     }
// ]

// let strBooks = JSON.stringify(books, undefined, 4)
// console.log(strBooks)


// localStorage.setItem(books, strBooks)

// let getBooks = localStorage.getItem(books)
// // console.log(getBooks)

// let objBooks = JSON.parse(getBooks)
// console.log(objBooks[0])

